# models/

By default the app downloads the weights from Hugging Face
(`ciCic/yolo11n-seg-bonnetjes`) on first start and caches them.

To use **your own** weights instead, put them here as `best.pt`
(a single-class YOLO11-seg checkpoint is ~6 MB, fine for GitHub).
Make sure `models/*.pt` is not ignored in `.gitignore` if you want to commit it.
