"""Offline tests: use a randomly initialised YOLO11n-seg (no network needed)."""
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import inference as inf  # noqa: E402


@pytest.fixture(scope="session")
def model(tmp_path_factory):
    from ultralytics import YOLO

    m = YOLO("yolo11n-seg.yaml")          # builds architecture, no download
    m.model.nc = 1
    path = tmp_path_factory.mktemp("w") / "rand.pt"
    m.save(str(path))
    return YOLO(str(path))


def test_predict_runs_and_returns_image(model):
    img = np.random.randint(0, 255, (480, 640, 3), dtype=np.uint8)
    res = inf.predict(model, img, conf=0.001)
    assert res.annotated_rgb.shape == img.shape
    assert isinstance(res.detections, list)


def test_predict_handles_no_detections(model):
    img = np.zeros((200, 300, 3), dtype=np.uint8)
    res = inf.predict(model, img, conf=0.99)
    assert res.detections == []


def test_deskew_straightens_rotated_rectangle():
    import cv2

    canvas = np.full((600, 800, 3), 40, dtype=np.uint8)
    rect = ((400, 300), (200, 450), 25)           # (center, (w, h), angle)
    box = cv2.boxPoints(rect).astype(np.int32)
    cv2.fillPoly(canvas, [box], (240, 240, 240))
    det = inf.Detection(1, "bonnetje", 0.9, (0, 0, 800, 600), polygon=box.astype(np.float32))
    out = inf.deskew_crop(canvas, det)
    assert out.shape[0] > out.shape[1]            # tall, like a receipt
    assert abs(out.shape[1] - 200) <= 6 and abs(out.shape[0] - 450) <= 6
    assert out.mean() > 200                       # mostly the light receipt, little background


def test_deskew_falls_back_without_polygon():
    img = np.zeros((100, 100, 3), dtype=np.uint8)
    det = inf.Detection(1, "bonnetje", 0.9, (10, 10, 60, 80), polygon=None)
    assert inf.deskew_crop(img, det).shape[0] > 0


def test_load_image_applies_limit_and_rgb(tmp_path):
    from PIL import Image

    p = tmp_path / "big.png"
    Image.new("RGB", (4000, 3000), (10, 20, 30)).save(p)
    arr = inf.load_image(p)
    assert max(arr.shape[:2]) == inf.MAX_SIDE and arr.shape[2] == 3


def test_png_bytes_roundtrip():
    arr = np.full((10, 10, 3), 128, dtype=np.uint8)
    assert inf.to_png_bytes(arr)[:8] == b"\x89PNG\r\n\x1a\n"
